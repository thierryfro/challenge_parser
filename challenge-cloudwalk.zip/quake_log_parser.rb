class QuakeLogParser
  def initialize(log_file)
    @log_file = log_file
  end

  def parse_log
    matches = []
    current_match = nil

    File.open(@log_file, "r").each_line do |line|
      line.strip!

      if line.empty?
        next
      end


      if kill_data = line.match(/^(\d+:\d+) Kill: (\d+) (\d+) (\d+): (.+)$/)

        kill_line = kill_data[0].match(/^(?:[^:]+:){3} (.+)$/)

        killer = kill_line[1].match(/^(.*?)\s+killed\s+(.*?)$/)

        victim = kill_line[1].match(/\bkilled\s+(.*?)\s+by\b/)

        current_match ||= { total_kills: 0, players: [], kills: {}, deaths: [] }

        killer_name = killer[1].strip
        victim_name = victim[1].strip

        if killer_name != "<world>" # Exclude "<world>" kills
          current_match[:total_kills] += 1

          current_match[:kills][killer_name] ||= 0
          current_match[:kills][killer_name] += 1

          current_match[:players] << killer_name unless current_match[:players].include?(killer_name)
        end

        # need to deal with <world> kills
        if killer_name == "<world>"  # "<world>" kills

          current_match[:total_kills] += 1
          current_match[:kills][victim_name] ||= 0
          current_match[:kills][victim_name] -= 1

        end

        current_match[:players] << victim_name unless current_match[:players].include?(victim_name)

        current_match[:kills][victim_name] ||= 0

        matches << current_match if current_match
      end
    end
    
    format_matches(matches)
  end

  private

  def format_matches(matches)
    formatted_matches = {}

    matches.each_with_index do |match, index|
      match_name = "game_#{index + 1}"
      formatted_matches[match_name] = {
        total_kills: match[:total_kills],
        players: match[:players],
        kills: match[:kills],
        deaths: match[:deaths]
      }
    end
    formatted_matches
  end
end

log_file = "qgames.log"
parser = QuakeLogParser.new(log_file)
parsed_data = parser.parse_log

parsed_data.each do |match_name, match_data|
  puts "#{match_name}:"
  puts "  total_kills: #{match_data[:total_kills]}"
  puts "  players: #{match_data[:players].join(', ')}"
  puts "  kills:"

  match_data[:kills].each do |player, kills|
    puts "    #{player}: #{kills}"
  end

  puts "\n"
end